`timescale 1ns / 1ps
`default_nettype none

module alu_tb;
  logic [15:0] a;
  logic [15:0] b;
  logic [3:0] op;
  wire [15:0] y;
  logic [15:0] expected;

  alu dut (.a(a), .b(b), .op(op), .y(y));

  task automatic check_case(
      input logic [3:0] test_op,
      input logic [15:0] test_a, test_b, test_expected);
    op = test_op;
    a = test_a;
    b = test_b;
    expected = test_expected;
    #10;
    if (y !== expected)
      $fatal(1, "ALU error: op=%0d A=%04h B=%04h expected=%04h actual=%04h",
             op, a, b, expected, y);
  endtask

  initial begin
    check_case(4'd1, 16'h1234, 16'h4321, 16'h5555);
    check_case(4'd2, 16'h1234, 16'h0024, 16'h1210);
    check_case(4'd3, 16'ha55a, 16'h0ff0, 16'h0550);
    check_case(4'd4, 16'ha55a, 16'h0ff0, 16'haffa);
    check_case(4'd5, 16'ha55a, 16'h0ff0, 16'haaaa);
    check_case(4'd6, 16'ha55a, 16'h0000, 16'h5aa5);

    check_case(4'd7, 16'h8001, 16'd17, 16'h0002);
    check_case(4'd8, 16'h8001, 16'd17, 16'h4000);
    check_case(4'd9, 16'h8001, 16'd17, 16'hc000);
    check_case(4'd10, 16'h8001, 16'd17, 16'h0003);

    $display("ALU basic simulation passed.");
    $finish;
  end
endmodule

`default_nettype wire
