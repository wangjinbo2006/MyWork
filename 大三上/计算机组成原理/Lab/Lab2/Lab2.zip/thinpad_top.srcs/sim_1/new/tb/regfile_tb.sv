`timescale 1ns / 1ps
`default_nettype none

module regfile_tb;
  logic clk = 1'b0;
  logic reset = 1'b1;
  logic [4:0] waddr = 5'd0;
  logic [15:0] wdata = 16'h0000;
  logic we = 1'b0;
  logic [4:0] raddr_a = 5'd1, raddr_b = 5'd2;
  wire [15:0] rdata_a, rdata_b;

  always #10 clk = ~clk;

  regfile dut (
      .clk(clk), .reset(reset), .waddr(waddr), .wdata(wdata), .we(we),
      .raddr_a(raddr_a), .rdata_a(rdata_a),
      .raddr_b(raddr_b), .rdata_b(rdata_b)
  );

  task automatic write_reg(input logic [4:0] addr, input logic [15:0] data);
    @(negedge clk);
    waddr = addr;
    wdata = data;
    we = 1'b1;
    @(negedge clk);
    we = 1'b0;
  endtask

  initial begin

    repeat (2) @(negedge clk);
    reset = 1'b0;
    #1;
    if (rdata_a !== 16'd0 || rdata_b !== 16'd0)
      $fatal(1, "RegFile reset failed");

    write_reg(5'd1, 16'd12);
    write_reg(5'd2, 16'd5);
    #1;
    if (rdata_a !== 16'd12 || rdata_b !== 16'd5)
      $fatal(1, "RegFile write/read failed");

    @(negedge clk);
    waddr = 5'd1;
    wdata = 16'hffff;
    @(negedge clk);
    #1;
    if (rdata_a !== 16'd12)
      $fatal(1, "RegFile write enable failed");

    write_reg(5'd0, 16'hffff);
    raddr_a = 5'd0;
    raddr_b = 5'd0;
    #1;
    if (rdata_a !== 16'd0 || rdata_b !== 16'd0)
      $fatal(1, "RegFile x0 failed");

    @(negedge clk);
    $display("RegFile basic simulation passed.");
    $finish;
  end
endmodule

`default_nettype wire
