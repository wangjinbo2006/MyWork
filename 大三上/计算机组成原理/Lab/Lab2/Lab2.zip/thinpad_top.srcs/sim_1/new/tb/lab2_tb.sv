`timescale 1ns / 1ps
`default_nettype none

module lab2_tb;
  logic clk_50M = 1'b0;
  logic reset_btn = 1'b1;
  logic push_btn = 1'b0;
  logic [31:0] dip_sw = 32'h00000000;
  wire [15:0] leds;

  always #10 clk_50M = ~clk_50M;

  lab2_top dut (
      .clk_50M(clk_50M), .clk_11M0592(1'b0),
      .push_btn(push_btn), .reset_btn(reset_btn),
      .touch_btn(4'b0000), .dip_sw(dip_sw), .leds(leds),
      .uart_dataready(1'b0), .uart_tbre(1'b1), .uart_tsre(1'b1),
      .rxd(1'b1), .sl811_intrq(1'b0), .sl811_drq_n(1'b1), .dm9k_int(1'b0)
  );

  task automatic send_inst(input logic [31:0] instruction);
    @(negedge clk_50M);
    dip_sw = instruction;
    push_btn = 1'b1;

    repeat (12) @(negedge clk_50M);
    push_btn = 1'b0;
    repeat (4) @(negedge clk_50M);
  endtask

  initial begin
    repeat (2) @(negedge clk_50M);
    reset_btn = 1'b0;

    send_inst(32'h000c008a);
    send_inst(32'h0005010a);
    send_inst(32'h00208089);
    send_inst(32'h00000092);
    if (leds !== 16'd17)
      $fatal(1, "ADD/PEEK failed: expected 17, actual %0d", leds);

    send_inst(32'h00208191);
    send_inst(32'h00000192);
    if (leds !== 16'd12)
      $fatal(1, "SUB/PEEK failed: expected 12, actual %0d", leds);

    send_inst(32'hffff000a);
    send_inst(32'h00000012);
    if (leds !== 16'd0)
      $fatal(1, "x0/PEEK failed: expected 0, actual %0d", leds);

    $display("Lab2 basic simulation passed: ADD=17, SUB=12, x0=0.");
    $finish;
  end
endmodule

`default_nettype wire
