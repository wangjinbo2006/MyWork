`timescale 1ns / 1ps
`default_nettype none

module controller (
    input wire clk,
    input wire reset,
    input wire step,
    input wire [31:0] dip_sw,
    output logic [15:0] leds,

    output wire [4:0] rf_raddr_a,
    input wire [15:0] rf_rdata_a,
    output wire [4:0] rf_raddr_b,
    input wire [15:0] rf_rdata_b,
    output wire [4:0] rf_waddr,
    output wire [15:0] rf_wdata,
    output wire rf_we,

    output wire [15:0] alu_a,
    output wire [15:0] alu_b,
    output wire [3:0] alu_op,
    input wire [15:0] alu_y
);
  typedef enum logic [2:0] {
    ST_INIT, ST_DECODE, ST_CALC, ST_WRITE_REG, ST_READ_REG
  } state_t;
  state_t state, next_state;
  logic [31:0] inst_reg;

  wire is_rtype = inst_reg[2:0] == 3'b001;
  wire is_poke = (inst_reg[2:0] == 3'b010) && (inst_reg[6:3] == 4'd1);
  wire is_peek = (inst_reg[2:0] == 3'b010) && (inst_reg[6:3] == 4'd2);

  always_ff @(posedge clk) begin
    if (reset) begin
      state <= ST_INIT;
      inst_reg <= 32'h00000000;
      leds <= 16'h0000;
    end else begin
      state <= next_state;
      if (state == ST_INIT && step)
        inst_reg <= dip_sw;
      if (state == ST_READ_REG)
        leds <= rf_rdata_a;
    end
  end

  always_comb begin
    next_state = state;
    case (state)
      ST_INIT: if (step) next_state = ST_DECODE;
      ST_DECODE: begin
        if (is_rtype) next_state = ST_CALC;
        else if (is_poke) next_state = ST_WRITE_REG;
        else if (is_peek) next_state = ST_READ_REG;
      end
      ST_CALC: next_state = ST_WRITE_REG;
      ST_WRITE_REG: next_state = ST_INIT;
      ST_READ_REG: next_state = ST_INIT;
    endcase
  end

  assign rf_raddr_a = is_peek ? inst_reg[11:7] : inst_reg[19:15];
  assign rf_raddr_b = inst_reg[24:20];
  assign rf_waddr = inst_reg[11:7];
  assign rf_wdata = is_poke ? inst_reg[31:16] : alu_y;
  assign rf_we = state == ST_WRITE_REG;
  assign alu_a = rf_rdata_a;
  assign alu_b = rf_rdata_b;
  assign alu_op = inst_reg[6:3];
endmodule

`default_nettype wire
