`timescale 1ns / 1ps
`default_nettype none

module button_trigger (
    input wire clk,
    input wire reset,
    input wire button,
    output wire step
);

  (* ASYNC_REG = "TRUE" *) logic button_meta, button_sync;
  logic button_prev;

  always_ff @(posedge clk) begin
    if (reset) begin
      button_meta <= 1'b0;
      button_sync <= 1'b0;
      button_prev <= 1'b0;
    end else begin
      button_meta <= button;
      button_sync <= button_meta;
      button_prev <= button_sync;
    end
  end

  assign step = button_sync & ~button_prev;
endmodule

`default_nettype wire
