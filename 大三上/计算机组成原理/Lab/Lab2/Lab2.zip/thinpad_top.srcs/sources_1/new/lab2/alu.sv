`timescale 1ns / 1ps
`default_nettype none

module alu (
    input  wire [15:0] a,
    input  wire [15:0] b,
    input  wire [ 3:0] op,
    output logic [15:0] y
);
  localparam logic [3:0]
      OP_ADD = 4'd1, OP_SUB = 4'd2, OP_AND = 4'd3, OP_OR  = 4'd4,
      OP_XOR = 4'd5, OP_NOT = 4'd6, OP_SLL = 4'd7, OP_SRL = 4'd8,
      OP_SRA = 4'd9, OP_ROL = 4'd10;

  wire [3:0] shamt;
  assign shamt = b[3:0];

  always_comb begin
    case (op)
      OP_ADD: y = a + b;
      OP_SUB: y = a - b;
      OP_AND: y = a & b;
      OP_OR:  y = a | b;
      OP_XOR: y = a ^ b;
      OP_NOT: y = ~a;
      OP_SLL: y = a << shamt;
      OP_SRL: y = a >> shamt;
      OP_SRA: y = $signed(a) >>> shamt;
      OP_ROL: y = (a << shamt) | (a >> (5'd16 - {1'b0, shamt}));
      default: y = 16'h0000;
    endcase
  end
endmodule

`default_nettype wire
