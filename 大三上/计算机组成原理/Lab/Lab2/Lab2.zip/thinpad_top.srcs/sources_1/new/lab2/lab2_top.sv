`timescale 1ns / 1ps
`default_nettype none

module lab2_top (
    input wire clk_50M,
    input wire clk_11M0592,

    input wire push_btn,
    input wire reset_btn,

    input  wire [ 3:0] touch_btn,
    input  wire [31:0] dip_sw,
    output wire [15:0] leds,
    output wire [ 7:0] dpy0,
    output wire [ 7:0] dpy1,

    output wire uart_rdn,
    output wire uart_wrn,
    input  wire uart_dataready,
    input  wire uart_tbre,
    input  wire uart_tsre,

    inout wire [31:0] base_ram_data,
    output wire [19:0] base_ram_addr,
    output wire [3:0] base_ram_be_n,
    output wire base_ram_ce_n,
    output wire base_ram_oe_n,
    output wire base_ram_we_n,

    inout wire [31:0] ext_ram_data,
    output wire [19:0] ext_ram_addr,
    output wire [3:0] ext_ram_be_n,
    output wire ext_ram_ce_n,
    output wire ext_ram_oe_n,
    output wire ext_ram_we_n,

    output wire txd,
    input  wire rxd,

    output wire [22:0] flash_a,
    inout wire [15:0] flash_d,
    output wire flash_rp_n,
    output wire flash_vpen,
    output wire flash_ce_n,
    output wire flash_oe_n,
    output wire flash_we_n,
    output wire flash_byte_n,

    output wire sl811_a0,

    output wire sl811_wr_n,
    output wire sl811_rd_n,
    output wire sl811_cs_n,
    output wire sl811_rst_n,
    output wire sl811_dack_n,
    input  wire sl811_intrq,
    input  wire sl811_drq_n,

    output wire dm9k_cmd,
    inout wire [15:0] dm9k_sd,
    output wire dm9k_iow_n,
    output wire dm9k_ior_n,
    output wire dm9k_cs_n,
    output wire dm9k_pwrst_n,
    input wire dm9k_int,

    output wire [2:0] video_red,
    output wire [2:0] video_green,
    output wire [1:0] video_blue,
    output wire       video_hsync,
    output wire       video_vsync,
    output wire       video_clk,
    output wire       video_de
);

  wire step;
  wire [4:0] rf_raddr_a, rf_raddr_b, rf_waddr;
  wire [15:0] rf_rdata_a, rf_rdata_b, rf_wdata;
  wire rf_we;
  wire [15:0] alu_a, alu_b, alu_y;
  wire [3:0] alu_op;

  button_trigger u_button (
      .clk(clk_50M), .reset(reset_btn), .button(push_btn), .step(step)
  );

  regfile u_regfile (
      .clk(clk_50M), .reset(reset_btn),
      .waddr(rf_waddr), .wdata(rf_wdata), .we(rf_we),
      .raddr_a(rf_raddr_a), .rdata_a(rf_rdata_a),
      .raddr_b(rf_raddr_b), .rdata_b(rf_rdata_b)
  );

  alu u_alu (
      .a(alu_a), .b(alu_b), .op(alu_op), .y(alu_y)
  );

  controller u_controller (
      .clk(clk_50M), .reset(reset_btn), .step(step), .dip_sw(dip_sw), .leds(leds),
      .rf_raddr_a(rf_raddr_a), .rf_rdata_a(rf_rdata_a),
      .rf_raddr_b(rf_raddr_b), .rf_rdata_b(rf_rdata_b),
      .rf_waddr(rf_waddr), .rf_wdata(rf_wdata), .rf_we(rf_we),
      .alu_a(alu_a), .alu_b(alu_b), .alu_op(alu_op), .alu_y(alu_y)
  );

  assign dpy0 = 8'h00;
  assign dpy1 = 8'h00;
  assign uart_rdn = 1'b1;
  assign uart_wrn = 1'b1;
  assign txd = 1'b1;

  assign base_ram_addr = 20'h00000;
  assign base_ram_be_n = 4'b0000;
  assign base_ram_ce_n = 1'b1;
  assign base_ram_oe_n = 1'b1;
  assign base_ram_we_n = 1'b1;
  assign base_ram_data = 32'bz;
  assign ext_ram_addr = 20'h00000;
  assign ext_ram_be_n = 4'b0000;
  assign ext_ram_ce_n = 1'b1;
  assign ext_ram_oe_n = 1'b1;
  assign ext_ram_we_n = 1'b1;
  assign ext_ram_data = 32'bz;

  assign flash_a = 23'h000000;
  assign flash_d = 16'bz;
  assign flash_rp_n = 1'b1;
  assign flash_vpen = 1'b0;
  assign flash_ce_n = 1'b1;
  assign flash_oe_n = 1'b1;
  assign flash_we_n = 1'b1;
  assign flash_byte_n = 1'b1;

  assign sl811_a0 = 1'b0;
  assign sl811_wr_n = 1'b1;
  assign sl811_rd_n = 1'b1;
  assign sl811_cs_n = 1'b1;
  assign sl811_rst_n = 1'b0;
  assign sl811_dack_n = 1'b1;
  assign dm9k_cmd = 1'b0;
  assign dm9k_sd = 16'bz;
  assign dm9k_iow_n = 1'b1;
  assign dm9k_ior_n = 1'b1;
  assign dm9k_cs_n = 1'b1;
  assign dm9k_pwrst_n = 1'b1;

  assign video_red = 3'b000;
  assign video_green = 3'b000;
  assign video_blue = 2'b00;
  assign video_hsync = 1'b0;
  assign video_vsync = 1'b0;
  assign video_clk = 1'b0;
  assign video_de = 1'b0;
endmodule

`default_nettype wire
