`timescale 1ns / 1ps
`default_nettype none

module regfile (
    input wire clk,
    input wire reset,
    input wire [4:0] waddr,
    input wire [15:0] wdata,
    input wire we,
    input wire [4:0] raddr_a,
    output wire [15:0] rdata_a,
    input wire [4:0] raddr_b,
    output wire [15:0] rdata_b
);

  logic [15:0] regs [1:31];

  always_ff @(posedge clk) begin
    if (reset) begin
      for (integer i = 1; i < 32; i = i + 1)
        regs[i] <= 16'h0000;
    end else if (we && waddr != 5'd0) begin
      regs[waddr] <= wdata;
    end
  end

  assign rdata_a = (raddr_a == 5'd0) ? 16'h0000 : regs[raddr_a];
  assign rdata_b = (raddr_b == 5'd0) ? 16'h0000 : regs[raddr_b];
endmodule

`default_nettype wire
